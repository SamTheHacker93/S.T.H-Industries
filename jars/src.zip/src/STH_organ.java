import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.util.Pair;

public class STH_organ extends BaseIndustry {

   public void apply() {
      super.apply(true);
      int size = this.market.getSize();
      this.demand("heavy_machinery", size + 1);
      this.demand("organics", size + 1);
      this.supply("organs", size);
      Pair deficit = this.getMaxDeficit(new String[]{"organics", "heavy_machinery"});
      this.applyDeficitToProduction(1, deficit, new String[]{"organs"});
      if(!this.isFunctional()) {
         this.supply.clear();
      }

   }

   public void unapply() {
      super.unapply();
   }
}
